﻿namespace TextMatch.Models
{
    public class TextMatchViewModel
    {
        public string Text { get; set; }
        public string SubText { get; set; }
        public string Output { get; set; }
    }
}